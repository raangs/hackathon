final=[float(x) for x in request.form.values()]
        # return final
    