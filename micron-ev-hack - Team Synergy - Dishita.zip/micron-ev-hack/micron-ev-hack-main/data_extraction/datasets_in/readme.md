
for getting poi.json, download from [here](https://github.com/openchargemap/ocm-data)