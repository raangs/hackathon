<html>
<head>
<style>
      body,
      html {
        height: 100%;
        margin: 0;
        font-family: Arial, Helvetica, sans-serif;
      }
      h2 {
        font-size: 30px;
      }
      .image {
        background-image: url("car.jpg");
        height: 100%;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        filter: blur(8px);
        -webkit-filter: blur(9px);
        -moz-filter: blur(10px);
        -o-filter: blur(6px);
        -ms-filter: blur(5px);
      }
      .text {
        color: #eeeeee;
        font-weight: bold;
        border: 3px solid #cccccc;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        padding: 20px;
        text-align: center;
      }
	  input[type=button],
      input[type=submit] {
        background-color: #c2c0bc;
        border-radius:10px;
        color: #000;
        padding: 15px 30px;
        text-decoration: none;
        margin: 3px 3px;
        cursor: pointer;
      }
	  table, td, th {
		border: 1px solid;
		color:white;
	}
    </style>
	</head>
	<body>
	 <div class="image"></div>
    <div class="text">
      <h1>Welcome!!!</h1><br>
    <form><h3>Enter city</h3></i></em>
	
    <input type="text" name="place"  style="width:20%" value=""><br><br>
	<input type="submit" name="sb" id="form-submit-button " value="Submit">

</form>
	<?php
if(isset($_REQUEST["sb"])){
	echo "<center>";
		$p_id=0;$o=0;$m=0;$p=0;$sum=0;
		$plc=$_REQUEST["place"];
		$conn=mysql_connect("localhost","root","") or die("could not connect to database");
	   //select the database
	   mysql_select_db("micron",$conn) or die(mysql_error());
	   //Write the query
	   $query="select * from evdata where place='".$plc."'";
	   //Execute the query
	   $result=mysql_query($query,$conn) or die(mysql_error());
	   //Handle the result
	   if(mysql_num_rows($result)<1){
			echo "Enter the place correctly!!!";
	   }
	   else{
		   echo "<table border='2' ><tr><th>Id</th><th>Place</th><th>No. of ev's</th><th>No. of charging stations</th><th>Type of area</th></tr>";
			while($row=mysql_fetch_array($result)){
				echo "<tr><td>$row[id]</td><td>$row[place]</td><td>$row[nev]</td><td>$row[ncs]</td><td>$row[typeofarea]</td></tr></center>";
				//$plac=$row[1];
			}
			echo "</table>";
			$q1="select ncs,nev,id,typeofarea from evdata where place='".$plc."'";
			//$q2="select nev from evdata where place='".$plc."'";
			$r1=mysql_query($q1,$conn);
			//echo "$r1";
			if($row=mysql_fetch_array($r1)){
				echo "No. of charging stations:$row[ncs]";
				if($row[3]=="household"){
					$ratio=10;
				}
				else if($row[3]=="industrial"){
					$ratio=15;
				}
				else{
					$ratio=20;
				}
				$req_st=round($row[1]/$ratio-$row[0]);
				
				$p_id=$row[2];
				echo "<br>No. of new charging stations can be established are:($req_st)";
			}
			$q="select * from areas where id='".$p_id."'";
			$r=mysql_query($q,$conn);
			if($row=mysql_fetch_array($r)){
				echo "<br>id:$row[id]<br>Place:$plc<br>No of offices:$row[offices]<br>No. of malls:$row[malls]<br>No. of parks:$row[parks]<br>";
				$o=$row[2];
				$m=$row[3];$p=$row[4];
				$sum=$o+$p+$m;
			}
			$req_o=round(($o/$sum)*$req_st);
			$req_m=round(($m/$sum)*$req_st);
			$req_p=round(($p/$sum)*$req_st);
			echo "<br>No of charging stations can be established near offices are:$req_o<br>
			No of charging stations can be established near malls are:$req_m<br>
			No of charging stations can be established near parks are:$req_p<br>";
	   }
	   echo "</center>";
	   
	   //$r2=mysql_query($q2,$conn);
	   //echo "$r1";
	  // $form=(mysql_query("select nev from evdata where place='".$plc."'")/10)-(mysql_query("select ncs from evdata where place='".$plc."'"));
	   //echo "$form";
	   //$newstations;
}         

?>
    </div>
	
</body>
	</html>
	
	
	
